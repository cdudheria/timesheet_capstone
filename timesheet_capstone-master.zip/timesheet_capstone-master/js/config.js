module.exports = {
    dbconn: "mongodb+srv://dbasir:ts12345@timesheetcapstone.ezi18.mongodb.net/timesheetDB?retryWrites=true&w=majority"
}
